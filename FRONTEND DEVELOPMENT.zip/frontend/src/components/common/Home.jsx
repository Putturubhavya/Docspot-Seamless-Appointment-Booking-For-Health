
import Landing from '../../landing';
import Header from './Header';

const Home = () => {
  return (
    <>
      <Header/>
      <Landing/>
    </>
  )
}

export default Home
